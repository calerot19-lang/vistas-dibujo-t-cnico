import { useEffect, useMemo, useRef, useState } from "react";
import IsoViewer from "./components/IsoViewer";
import LineGrid from "./components/LineGrid";
import Report from "./components/Report";
import { LEVELS, countCubes, piecesOfLevel, randomPiece, type Piece } from "./lib/pieces";
import {
  compareSegments,
  computeDepths,
  solutionSegments,
  type SegFeedback,
  type SegSet,
} from "./lib/segments";
import {
  clearSave,
  loadSave,
  persist,
  storageAvailable,
  type SaveData,
  type StoredResult,
} from "./lib/storage";

type ViewKey = "alzado" | "perfil" | "planta";
const VIEWS: ViewKey[] = ["alzado", "perfil", "planta"];
const VIEW_NAME: Record<ViewKey, string> = {
  alzado: "alzado",
  perfil: "perfil",
  planta: "planta",
};

/** Resultado definitivo de una pieza ya corregida. */
interface Result {
  segs: Record<ViewKey, SegSet>;
  feedback: Record<ViewKey, SegFeedback>;
  errors: number;
  score: number; // % de acierto
  time: number;
}

function Btn({
  children,
  onClick,
  tone = "slate",
  disabled,
  title,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  tone?: "slate" | "indigo" | "green" | "ghost";
  disabled?: boolean;
  title?: string;
}) {
  const tones: Record<string, string> = {
    slate: "bg-slate-800 text-white hover:bg-slate-700 shadow-sm",
    indigo: "bg-indigo-600 text-white hover:bg-indigo-500 shadow-sm shadow-indigo-200",
    green: "bg-emerald-600 text-white hover:bg-emerald-500 shadow-sm shadow-emerald-200",
    ghost: "bg-white text-slate-700 border border-slate-300 hover:bg-slate-50",
  };
  return (
    <button
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={`rounded-lg px-3.5 py-2 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-40 ${tones[tone]}`}
    >
      {children}
    </button>
  );
}

export default function App() {
  const [level, setLevel] = useState<1 | 2 | 3>(1);
  const [index, setIndex] = useState(0);
  const [custom, setCustom] = useState<Piece | null>(null);
  const list = useMemo(() => piecesOfLevel(level), [level]);
  const piece = custom ?? list[Math.min(index, list.length - 1)];

  // Solución: aristas visibles de cada vista
  const solution = useMemo(() => {
    const d = computeDepths(piece);
    return {
      alzado: solutionSegments(d.alzado),
      perfil: solutionSegments(d.perfil),
      planta: solutionSegments(d.planta),
    };
  }, [piece]);

  // Datos guardados en el navegador (alumno + resultados)
  const [save, setSave] = useState<SaveData>(() => loadSave());
  const canStore = useMemo(() => storageAvailable(), []);
  const [showReport, setShowReport] = useState(false);
  const [showIdentity, setShowIdentity] = useState(() => !loadSave().student);

  useEffect(() => {
    persist(save);
  }, [save]);

  /** Reconstruye el resultado (con Sets) a partir de lo guardado. */
  const result: Result | null = useMemo(() => {
    const r = save.results[piece.id];
    if (!r) return null;
    const mk = (f: { correct: string[]; extra: string[]; missing: string[] }): SegFeedback => ({
      correct: new Set(f.correct),
      extra: new Set(f.extra),
      missing: new Set(f.missing),
    });
    return {
      segs: {
        alzado: new Set(r.segs.alzado),
        perfil: new Set(r.segs.perfil),
        planta: new Set(r.segs.planta),
      },
      feedback: {
        alzado: mk(r.feedback.alzado),
        perfil: mk(r.feedback.perfil),
        planta: mk(r.feedback.planta),
      },
      errors: r.errors,
      score: r.score,
      time: r.time,
    };
  }, [save.results, piece.id]);
  const done = !!result;
  const results = save.results;

  const [segs, setSegs] = useState<Record<ViewKey, SegSet>>({
    alzado: new Set(),
    perfil: new Set(),
    planta: new Set(),
  });
  const [confirmCheck, setConfirmCheck] = useState(false);

  const [tool, setTool] = useState<"line" | "erase">("line");
  const [helperGrid, setHelperGrid] = useState(true);

  const DEFAULT_AZ = 315;
  const [azimuth, setAzimuth] = useState(DEFAULT_AZ);
  const [elevation, setElevation] = useState(30);
  const [labels, setLabels] = useState(true);
  const [seconds, setSeconds] = useState(0);
  const timerOn = useRef(true);

  // Al cambiar de pieza: lámina limpia, o el trabajo ya corregido si existe
  useEffect(() => {
    setConfirmCheck(false);
    setTool("line");
    const r = save.results[piece.id];
    if (r) {
      setSegs({
        alzado: new Set(r.segs.alzado),
        perfil: new Set(r.segs.perfil),
        planta: new Set(r.segs.planta),
      });
      setSeconds(r.time);
      timerOn.current = false;
    } else {
      setSegs({ alzado: new Set(), perfil: new Set(), planta: new Set() });
      setSeconds(0);
      timerOn.current = true;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [piece]);

  useEffect(() => {
    const id = setInterval(() => {
      if (timerOn.current) setSeconds((s) => s + 1);
    }, 1000);
    return () => clearInterval(id);
  }, []);

  // Atajos: L = lápiz, E = goma
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      if (e.key === "l" || e.key === "L") setTool("line");
      if (e.key === "e" || e.key === "E" || e.key === "g" || e.key === "G") setTool("erase");
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  function update(key: ViewKey, next: SegSet) {
    if (done) return;
    setSegs((s) => ({ ...s, [key]: next }));
  }

  // Comprobar solo con las tres vistas dibujadas
  const MIN_SEGS = 4;
  const missingViews = VIEWS.filter((k) => segs[k].size < MIN_SEGS);
  const canCheck = !done && missingViews.length === 0;

  function check() {
    if (!canCheck) return;
    const feedback = {
      alzado: compareSegments(segs.alzado, solution.alzado),
      perfil: compareSegments(segs.perfil, solution.perfil),
      planta: compareSegments(segs.planta, solution.planta),
    };
    let errors = 0;
    let total = 0;
    VIEWS.forEach((k) => {
      errors += feedback[k].extra.size + feedback[k].missing.size;
      total += solution[k].size;
    });
    const score = Math.max(0, Math.round(((total - errors) / total) * 100));
    timerOn.current = false;
    setConfirmCheck(false);

    const ser = (s: SegSet) => [...s];
    const stored: StoredResult = {
      pieceId: piece.id,
      pieceName: custom ? "Pieza aleatoria" : piece.name,
      level: piece.level,
      random: !!custom,
      errors,
      score,
      time: seconds,
      date: new Date().toISOString(),
      detail: {
        alzado: feedback.alzado.extra.size + feedback.alzado.missing.size,
        perfil: feedback.perfil.extra.size + feedback.perfil.missing.size,
        planta: feedback.planta.extra.size + feedback.planta.missing.size,
      },
      segs: { alzado: ser(segs.alzado), perfil: ser(segs.perfil), planta: ser(segs.planta) },
      feedback: {
        alzado: {
          correct: ser(feedback.alzado.correct),
          extra: ser(feedback.alzado.extra),
          missing: ser(feedback.alzado.missing),
        },
        perfil: {
          correct: ser(feedback.perfil.correct),
          extra: ser(feedback.perfil.extra),
          missing: ser(feedback.perfil.missing),
        },
        planta: {
          correct: ser(feedback.planta.correct),
          extra: ser(feedback.planta.extra),
          missing: ser(feedback.planta.missing),
        },
      },
    };
    setSave((s) => ({ ...s, results: { ...s.results, [piece.id]: stored } }));
  }

  function resetAll() {
    if (!confirm("¿Borrar todos los resultados guardados y empezar de nuevo?")) return;
    clearSave();
    setSave({ student: "", group: "", results: {} });
    setSegs({ alzado: new Set(), perfil: new Set(), planta: new Set() });
    setSeconds(0);
    timerOn.current = true;
    setShowReport(false);
    setShowIdentity(true);
  }

  function go(delta: number) {
    setCustom(null);
    setIndex((i) => {
      const base = custom ? 0 : i;
      return (base + delta + list.length) % list.length;
    });
  }

  const cell = Math.max(
    26,
    Math.min(56, Math.floor(360 / Math.max(piece.W + piece.D, piece.H + piece.D))),
  );

  const correctedCount = list.filter((p) => results[p.id]).length;
  const perfectCount = list.filter((p) => results[p.id]?.errors === 0).length;
  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");
  const drawnTotal = segs.alzado.size + segs.perfil.size + segs.planta.size;

  return (
    <div className="min-h-screen bg-[radial-gradient(900px_500px_at_20%_-10%,#e0e7ff_0%,transparent_60%),radial-gradient(800px_500px_at_100%_0%,#ccfbf1_0%,transparent_55%)] bg-slate-50 pb-14">
      {/* Cabecera */}
      <header className="border-b border-slate-200/70 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-teal-500 text-white shadow">
            <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M12 2.8 20.5 7.4 12 12 3.5 7.4z" />
              <path d="M3.5 7.4v9.2L12 21.2V12" />
              <path d="M20.5 7.4v9.2L12 21.2" />
            </svg>
          </div>
          <div className="mr-auto">
            <h1 className="text-lg font-black leading-tight tracking-tight text-slate-900">
              Vistas de piezas · dibuja con líneas
            </h1>
            <p className="text-xs text-slate-500">
              Traza el <b>alzado</b>, el <b>perfil</b> y la <b>planta</b> · sistema europeo ·
              autocorrección
            </p>
          </div>
          <button
            onClick={() => setShowIdentity(true)}
            title="Cambiar nombre y grupo"
            className="flex items-center gap-2 rounded-xl bg-white px-3 py-1.5 text-sm font-semibold text-slate-700 ring-1 ring-slate-200 hover:bg-slate-50"
          >
            👤 {save.student || "Identifícate"}
            {save.group && <span className="text-slate-400">· {save.group}</span>}
          </button>
          <div className="flex items-center gap-2 rounded-xl bg-slate-100 px-3 py-1.5 text-sm font-semibold text-slate-600">
            ⏱ {mm}:{ss}
          </div>
          <div className="flex items-center gap-2 rounded-xl bg-emerald-50 px-3 py-1.5 text-sm font-semibold text-emerald-700">
            ✓ {perfectCount} perfectas · {correctedCount}/{list.length} corregidas
          </div>
          <button
            onClick={() => setShowReport(true)}
            className="rounded-xl bg-indigo-600 px-3 py-1.5 text-sm font-bold text-white shadow-sm shadow-indigo-200 hover:bg-indigo-500"
          >
            📄 Informe
          </button>
        </div>
        {!canStore && (
          <div className="bg-amber-100 px-4 py-1 text-center text-xs font-semibold text-amber-800">
            ⚠ Este navegador no permite guardar datos (modo privado): los resultados se perderán al
            recargar. Genera el informe antes de cerrar.
          </div>
        )}
      </header>

      {/* Niveles y piezas */}
      <div className="mx-auto max-w-6xl px-4 pt-4">
        <div className="flex flex-wrap items-center gap-2">
          {LEVELS.map((l) => (
            <button
              key={l.level}
              title={l.desc}
              onClick={() => {
                setLevel(l.level);
                setIndex(0);
                setCustom(null);
              }}
              className={`rounded-full px-4 py-1.5 text-sm font-bold transition ${
                level === l.level
                  ? "bg-indigo-600 text-white shadow shadow-indigo-200"
                  : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50"
              }`}
            >
              {l.label}
            </button>
          ))}
          <div className="ml-auto">
            <Btn tone="ghost" onClick={() => setCustom(randomPiece(level))}>
              🎲 Pieza aleatoria
            </Btn>
          </div>
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          {list.map((p, i) => {
            const active = !custom && p.id === piece.id;
            const r = results[p.id];
            return (
              <button
                key={p.id}
                title={
                  r
                    ? `Corregida · ${r.score}% de acierto`
                    : `Pieza ${i + 1} · pendiente`
                }
                onClick={() => {
                  setCustom(null);
                  setIndex(i);
                }}
                className={`h-8 w-8 rounded-lg text-xs font-bold transition ${
                  active
                    ? "bg-slate-800 text-white"
                    : r
                      ? r.errors === 0
                        ? "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-300 hover:bg-emerald-200"
                        : "bg-rose-100 text-rose-700 ring-1 ring-rose-300 hover:bg-rose-200"
                      : "bg-white text-slate-500 ring-1 ring-slate-200 hover:bg-slate-100"
                }`}
              >
                {r ? (r.errors === 0 ? "✓" : "✕") : i + 1}
              </button>
            );
          })}
          {custom && (
            <span className="rounded-lg bg-amber-100 px-2 py-1 text-xs font-bold text-amber-700 ring-1 ring-amber-300">
              🎲 aleatoria
            </span>
          )}
        </div>
      </div>

      {/* Panel principal */}
      <main className="mx-auto mt-4 grid max-w-6xl gap-4 px-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)]">
        {/* Pieza 3D */}
        <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="mb-2 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-black uppercase tracking-wider text-slate-500">
                Pieza {custom ? "aleatoria" : `${index + 1} · ${piece.name}`}
              </h2>
              <p className="text-xs text-slate-400">
                {countCubes(piece)} cubos · caja {piece.W}×{piece.D}×{piece.H}
              </p>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setAzimuth((a) => (a - 45 + 360) % 360)}
                className="rounded-lg bg-slate-100 px-2.5 py-1.5 text-sm hover:bg-slate-200"
                title="Girar a la izquierda"
              >
                ↺
              </button>
              <button
                onClick={() => setAzimuth((a) => (a + 45) % 360)}
                className="rounded-lg bg-slate-100 px-2.5 py-1.5 text-sm hover:bg-slate-200"
                title="Girar a la derecha"
              >
                ↻
              </button>
              <button
                onClick={() => {
                  setAzimuth(DEFAULT_AZ);
                  setElevation(30);
                }}
                className="rounded-lg bg-slate-100 px-2.5 py-1.5 text-xs font-semibold hover:bg-slate-200"
                title="Volver a la posición inicial"
              >
                Reiniciar vista
              </button>
            </div>
          </div>

          <div className="relative rounded-xl bg-[linear-gradient(#eef2ff_1px,transparent_1px),linear-gradient(90deg,#eef2ff_1px,transparent_1px)] [background-size:22px_22px]">
            <IsoViewer
              piece={piece}
              azimuth={azimuth}
              elevation={elevation}
              size={380}
              showLabels={labels}
            />
            {azimuth !== DEFAULT_AZ && (
              <span className="absolute left-2 top-2 rounded-md bg-amber-100 px-2 py-1 text-[11px] font-bold text-amber-700">
                Vista girada · el alzado sigue siendo el mismo
              </span>
            )}
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-4 text-xs text-slate-500">
            <label className="flex items-center gap-2">
              <span className="font-semibold">Inclinación</span>
              <input
                type="range"
                min={8}
                max={70}
                value={elevation}
                onChange={(e) => setElevation(Number(e.target.value))}
                className="accent-indigo-600"
              />
            </label>
            <label className="flex cursor-pointer items-center gap-2">
              <input
                type="checkbox"
                checked={labels}
                onChange={(e) => setLabels(e.target.checked)}
                className="accent-indigo-600"
              />
              <span className="font-semibold">Direcciones de observación</span>
            </label>
          </div>
        </section>

        {/* Tablero de dibujo */}
        <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <h2 className="mr-auto text-sm font-black uppercase tracking-wider text-slate-500">
              {done ? "Tu dibujo corregido" : "Tu dibujo"}
            </h2>
            {!done && (
              <>
                <div className="flex overflow-hidden rounded-lg ring-1 ring-slate-300">
                  <button
                    onClick={() => setTool("line")}
                    title="Dibujar línea (tecla L)"
                    className={`px-3 py-1.5 text-sm font-bold transition ${
                      tool === "line"
                        ? "bg-indigo-600 text-white"
                        : "bg-white text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    ✏️ Línea
                  </button>
                  <button
                    onClick={() => setTool("erase")}
                    title="Borrar una línea (tecla E)"
                    className={`px-3 py-1.5 text-sm font-bold transition ${
                      tool === "erase"
                        ? "bg-rose-600 text-white"
                        : "bg-white text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    🧽 Goma
                  </button>
                </div>
                <label className="flex cursor-pointer items-center gap-1.5 text-xs font-semibold text-slate-500">
                  <input
                    type="checkbox"
                    checked={helperGrid}
                    onChange={(e) => setHelperGrid(e.target.checked)}
                    className="accent-indigo-600"
                  />
                  Retícula
                </label>
              </>
            )}
          </div>

          {done ? (
            <p className="mb-3 rounded-lg bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-500">
              🔒 Ejercicio corregido y finalizado. Esta es tu lámina con la corrección; no se puede
              modificar. Continúa con la siguiente pieza.
            </p>
          ) : (
            <p className="mb-3 text-xs text-slate-400">
              Arrastra <b>de un punto a otro</b> para trazar una línea recta (horizontal o
              vertical). Si te equivocas, usa la <b>goma</b> sobre la línea que quieras eliminar.
              Dibuja el contorno <b>y también las aristas interiores</b> de los escalones.
            </p>
          )}

          <div className="inline-grid grid-cols-[auto_auto] items-start justify-items-start gap-x-8 gap-y-6">
            <LineGrid
              title="Alzado"
              subtitle="vista de frente"
              rows={piece.H}
              cols={piece.W}
              cell={cell}
              segments={segs.alzado}
              feedback={result?.feedback.alzado}
              tool={tool}
              showHelperGrid={helperGrid}
              accent="text-indigo-600"
              locked={done}
              onChange={(n) => update("alzado", n)}
            />
            <LineGrid
              title="Perfil izquierdo"
              subtitle="visto desde la izquierda"
              rows={piece.H}
              cols={piece.D}
              cell={cell}
              segments={segs.perfil}
              feedback={result?.feedback.perfil}
              tool={tool}
              showHelperGrid={helperGrid}
              accent="text-teal-600"
              locked={done}
              onChange={(n) => update("perfil", n)}
            />
            <LineGrid
              title="Planta"
              subtitle="vista desde arriba"
              rows={piece.D}
              cols={piece.W}
              cell={cell}
              segments={segs.planta}
              feedback={result?.feedback.planta}
              tool={tool}
              showHelperGrid={helperGrid}
              accent="text-amber-600"
              locked={done}
              onChange={(n) => update("planta", n)}
            />
          </div>

          {/* Mensajes */}
          <div className="mt-4 min-h-[54px]">
            {done && result.errors === 0 && (
              <div className="flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-3 text-emerald-800">
                <span className="text-xl">🎉</span>
                <b>¡Perfecto! Las tres vistas están bien trazadas.</b>
                <span className="text-sm">
                  100% · tiempo {mm}:{ss}
                </span>
              </div>
            )}
            {done && result.errors > 0 && (
              <div className="rounded-xl border border-rose-300 bg-rose-50 px-4 py-3 text-sm text-rose-800">
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                  <b>
                    Corrección: {result.errors}{" "}
                    {result.errors === 1 ? "línea incorrecta" : "líneas incorrectas"}
                  </b>
                  <span className="rounded-md bg-white px-2 py-0.5 text-xs font-bold text-rose-700 ring-1 ring-rose-200">
                    {result.score}% de acierto
                  </span>
                  <span className="text-xs">
                    {VIEWS.map((k) => {
                      const f = result.feedback[k];
                      const n = f.extra.size + f.missing.size;
                      return `${VIEW_NAME[k]}: ${n === 0 ? "✔" : n}`;
                    }).join("  ·  ")}
                  </span>
                </div>
                <div className="mt-2 flex flex-wrap gap-4 text-xs">
                  <span className="flex items-center gap-1.5">
                    <svg width="26" height="8">
                      <line x1="1" y1="4" x2="25" y2="4" stroke="#059669" strokeWidth="4" strokeLinecap="round" />
                    </svg>
                    bien trazada
                  </span>
                  <span className="flex items-center gap-1.5">
                    <svg width="26" height="8">
                      <line x1="1" y1="4" x2="25" y2="4" stroke="#dc2626" strokeWidth="4" strokeLinecap="round" />
                    </svg>
                    sobra
                  </span>
                  <span className="flex items-center gap-1.5">
                    <svg width="26" height="8">
                      <line
                        x1="1"
                        y1="4"
                        x2="25"
                        y2="4"
                        stroke="#f43f5e"
                        strokeWidth="3"
                        strokeDasharray="6 4"
                        strokeLinecap="round"
                      />
                    </svg>
                    faltaba
                  </span>
                </div>
              </div>
            )}
            {!done && (
              <div className="text-xs text-slate-400">
                Líneas trazadas: <b>{drawnTotal}</b>
                {missingViews.length > 0 && (
                  <>
                    {" "}
                    · aún te falta dibujar:{" "}
                    <b className="text-rose-500">
                      {missingViews.map((k) => VIEW_NAME[k]).join(", ")}
                    </b>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Botonera */}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            {!done && (
              <Btn
                tone="indigo"
                onClick={() => setConfirmCheck(true)}
                disabled={!canCheck}
                title={
                  canCheck
                    ? "Entregar y corregir (no podrás modificarlo después)"
                    : "Primero debes dibujar las tres vistas completas"
                }
              >
                ✓ Comprobar
              </Btn>
            )}
            {done && (
              <Btn tone="green" onClick={() => go(1)}>
                Siguiente pieza →
              </Btn>
            )}
            {!canCheck && !done && (
              <span className="text-xs font-semibold text-slate-400">
                🔒 Se activa al tener dibujadas las tres vistas
              </span>
            )}
            <div className="ml-auto flex gap-2">
              <Btn tone="slate" onClick={() => go(-1)} title="Pieza anterior">
                ←
              </Btn>
              <Btn tone="slate" onClick={() => go(1)} title="Pieza siguiente">
                →
              </Btn>
            </div>
          </div>
        </section>
      </main>

      {/* Ayuda */}
      <section className="mx-auto mt-5 max-w-6xl px-4">
        <details className="rounded-2xl border border-slate-200 bg-white p-4 text-sm text-slate-600 shadow-sm">
          <summary className="cursor-pointer text-sm font-black uppercase tracking-wider text-slate-500">
            Cómo dibujar las vistas (sistema europeo)
          </summary>
          <div className="mt-3 grid gap-4 md:grid-cols-3">
            <div className="rounded-xl bg-indigo-50 p-3">
              <b className="text-indigo-700">Alzado</b>
              <p className="mt-1 text-xs">
                Lo que ves mirando la pieza <b>de frente</b>. Va arriba a la izquierda y define la
                anchura y la altura.
              </p>
            </div>
            <div className="rounded-xl bg-teal-50 p-3">
              <b className="text-teal-700">Perfil izquierdo</b>
              <p className="mt-1 text-xs">
                Mirando la pieza <b>desde su lado izquierdo</b>. En el 1.er diedro se dibuja a la{" "}
                <b>derecha</b> del alzado y comparte con él la altura.
              </p>
            </div>
            <div className="rounded-xl bg-amber-50 p-3">
              <b className="text-amber-700">Planta</b>
              <p className="mt-1 text-xs">
                Vista <b>desde arriba</b>. Se dibuja <b>debajo</b> del alzado y comparte con él la
                anchura.
              </p>
            </div>
          </div>
          <ul className="mt-3 list-disc space-y-1 pl-5 text-xs text-slate-500">
            <li>
              Dibuja <b>el contorno exterior</b> de cada vista y, además, las <b>aristas
              interiores</b>: toda línea donde la superficie cambia de profundidad (un escalón).
            </li>
            <li>No hace falta dibujar las aristas ocultas con trazo discontinuo en esta actividad.</li>
            <li>
              Si te equivocas, usa la <b>goma</b> sobre la línea concreta que quieras eliminar
              (atajos: <b>L</b> = lápiz, <b>E</b> = goma).
            </li>
            <li>
              <b>Solo hay una oportunidad por pieza</b>: el botón <i>Comprobar</i> se activa cuando
              están dibujadas las tres vistas y, al pulsarlo, el ejercicio queda <b>entregado y
              corregido</b> sobre tu propia lámina. No se puede retocar ni repetir.
            </li>
            <li>Revisa bien tu trabajo antes de comprobar y después continúa con otra pieza.</li>
          </ul>
        </details>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-center text-xs text-slate-400">
          <span>
            Actividad interactiva de Dibujo Técnico · traza, entrega y revisa tu corrección.
          </span>
          {canStore && (
            <>
              <span className="text-slate-300">|</span>
              <span>💾 Tus resultados se guardan en este navegador.</span>
              <button onClick={resetAll} className="font-semibold text-rose-500 hover:underline">
                Borrar mis datos
              </button>
            </>
          )}
        </div>
      </section>

      {/* Confirmación antes de corregir */}
      {confirmCheck && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl">
            <h3 className="text-base font-black text-slate-900">¿Entregar y corregir?</h3>
            <p className="mt-2 text-sm text-slate-600">
              La corrección aparecerá sobre tu dibujo y el ejercicio quedará{" "}
              <b>finalizado</b>: no podrás modificarlo ni volver a intentarlo. Asegúrate de haber
              revisado las tres vistas.
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <Btn tone="ghost" onClick={() => setConfirmCheck(false)}>
                Revisar un poco más
              </Btn>
              <Btn tone="indigo" onClick={check}>
                Sí, corregir
              </Btn>
            </div>
          </div>
        </div>
      )}

      {/* Identificación del alumno */}
      {showIdentity && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setShowIdentity(false);
            }}
            className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl"
          >
            <h3 className="text-base font-black text-slate-900">¿Quién está trabajando?</h3>
            <p className="mt-1 text-sm text-slate-500">
              Tu nombre aparecerá en el informe final que debes entregar al profesor/a.
            </p>
            <label className="mt-4 block text-xs font-bold uppercase tracking-wide text-slate-500">
              Nombre y apellidos
              <input
                autoFocus
                value={save.student}
                onChange={(e) => setSave((s) => ({ ...s, student: e.target.value }))}
                placeholder="Ej.: Lucía Martín García"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-normal normal-case tracking-normal text-slate-800 outline-none focus:border-indigo-500"
              />
            </label>
            <label className="mt-3 block text-xs font-bold uppercase tracking-wide text-slate-500">
              Curso / grupo
              <input
                value={save.group}
                onChange={(e) => setSave((s) => ({ ...s, group: e.target.value }))}
                placeholder="Ej.: 3.º ESO B"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-normal normal-case tracking-normal text-slate-800 outline-none focus:border-indigo-500"
              />
            </label>
            <div className="mt-4 flex justify-end gap-2">
              <Btn tone="indigo">Empezar</Btn>
            </div>
          </form>
        </div>
      )}

      {/* Informe */}
      {showReport && <Report data={save} onClose={() => setShowReport(false)} />}
    </div>
  );
}
