import { useMemo } from "react";
import type { Piece } from "../lib/pieces";
import { solid } from "../lib/pieces";

type V3 = [number, number, number];

const FACES: { n: V3; corners: V3[] }[] = [
  { n: [1, 0, 0], corners: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]] },
  { n: [-1, 0, 0], corners: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]] },
  { n: [0, 1, 0], corners: [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]] },
  { n: [0, -1, 0], corners: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]] },
  { n: [0, 0, 1], corners: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]] },
  { n: [0, 0, -1], corners: [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]] },
];

const COLORS: Record<string, string> = {
  top: "#cdd7fe",
  bottom: "#5b63c4",
  x: "#7a84e8",
  y: "#9ea8f4",
};

function faceColor(n: V3): string {
  if (n[2] === 1) return COLORS.top;
  if (n[2] === -1) return COLORS.bottom;
  if (n[0] !== 0) return COLORS.x;
  return COLORS.y;
}

interface Props {
  piece: Piece;
  azimuth: number; // grados
  elevation: number; // grados
  size?: number;
  showLabels?: boolean;
}

export default function IsoViewer({
  piece,
  azimuth,
  elevation,
  size = 380,
  showLabels = true,
}: Props) {
  const svg = useMemo(() => {
    const a = (azimuth * Math.PI) / 180;
    const e = (elevation * Math.PI) / 180;
    // vector hacia la cámara
    const C: V3 = [Math.cos(e) * Math.sin(a), -Math.cos(e) * Math.cos(a), Math.sin(e)];
    const R: V3 = [Math.cos(a), Math.sin(a), 0];
    const U: V3 = [
      C[1] * R[2] - C[2] * R[1],
      C[2] * R[0] - C[0] * R[2],
      C[0] * R[1] - C[1] * R[0],
    ];
    const cx = piece.W / 2;
    const cy = piece.D / 2;
    const cz = piece.H / 2;

    const proj = (p: V3): [number, number] => {
      const q: V3 = [p[0] - cx, p[1] - cy, p[2] - cz];
      return [q[0] * R[0] + q[1] * R[1] + q[2] * R[2], -(q[0] * U[0] + q[1] * U[1] + q[2] * U[2])];
    };
    const dot = (p: V3, q: V3) => p[0] * q[0] + p[1] * q[1] + p[2] * q[2];

    // escala para encajar la caja envolvente (con margen para las etiquetas)
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    const m = showLabels ? 1.6 : 0.1;
    for (const px of [-m, piece.W + m])
      for (const py of [-m, piece.D + m])
        for (const pz of [-0.1, piece.H + m]) {
          const [sx, sy] = proj([px, py, pz]);
          minX = Math.min(minX, sx);
          maxX = Math.max(maxX, sx);
          minY = Math.min(minY, sy);
          maxY = Math.max(maxY, sy);
        }
    const pad = 10;
    const scale = Math.min((size - 2 * pad) / (maxX - minX), (size - 2 * pad) / (maxY - minY));
    const ox = size / 2 - ((minX + maxX) / 2) * scale;
    const oy = size / 2 - ((minY + maxY) / 2) * scale;
    const S = (p: V3): [number, number] => {
      const [sx, sy] = proj(p);
      return [sx * scale + ox, sy * scale + oy];
    };

    // ordenar cubos de lejos a cerca
    const voxels: { x: number; y: number; z: number; d: number }[] = [];
    for (let z = 0; z < piece.H; z++)
      for (let y = 0; y < piece.D; y++)
        for (let x = 0; x < piece.W; x++) {
          if (!piece.cells[z][y][x]) continue;
          voxels.push({ x, y, z, d: dot([x + 0.5, y + 0.5, z + 0.5], C) });
        }
    voxels.sort((p, q) => p.d - q.d);

    const polys: { points: string; fill: string }[] = [];
    for (const v of voxels) {
      for (const f of FACES) {
        if (dot(f.n, C) <= 0.001) continue;
        if (solid(piece, v.x + f.n[0], v.y + f.n[1], v.z + f.n[2])) continue;
        const pts = f.corners
          .map((c) => S([v.x + c[0], v.y + c[1], v.z + c[2]]))
          .map(([px, py]) => `${px.toFixed(2)},${py.toFixed(2)}`)
          .join(" ");
        polys.push({ points: pts, fill: faceColor(f.n) });
      }
    }

    // etiquetas de dirección de observación
    type Label = { text: string; x: number; y: number; ax: number; ay: number; show: boolean };
    const labels: Label[] = [];
    const mk = (text: string, from: V3, to: V3, n: V3) => {
      const [fx, fy] = S(from);
      const [tx, ty] = S(to);
      labels.push({ text, x: fx, y: fy, ax: tx, ay: ty, show: dot(n, C) > 0.15 });
    };
    if (showLabels) {
      mk("ALZADO", [piece.W / 2, -1.5, piece.H / 2], [piece.W / 2, -0.15, piece.H / 2], [0, -1, 0]);
      mk("PERFIL", [-1.5, piece.D / 2, piece.H / 2], [-0.15, piece.D / 2, piece.H / 2], [-1, 0, 0]);
      mk(
        "PLANTA",
        [piece.W / 2, piece.D / 2, piece.H + 1.4],
        [piece.W / 2, piece.D / 2, piece.H + 0.15],
        [0, 0, 1],
      );
    }

    return { polys, labels };
  }, [piece, azimuth, elevation, size, showLabels]);

  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      className="h-full w-full select-none"
      style={{ maxHeight: size }}
    >
      <defs>
        <marker id="arrowhead" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
          <path d="M0,0 L6,3 L0,6 z" fill="#0f766e" />
        </marker>
      </defs>
      {svg.polys.map((p, i) => (
        <polygon
          key={i}
          points={p.points}
          fill={p.fill}
          stroke="#2f327a"
          strokeWidth={1.4}
          strokeLinejoin="round"
        />
      ))}
      {svg.labels
        .filter((l) => l.show)
        .map((l) => (
          <g key={l.text}>
            <line
              x1={l.x}
              y1={l.y}
              x2={l.ax}
              y2={l.ay}
              stroke="#0f766e"
              strokeWidth={1.6}
              markerEnd="url(#arrowhead)"
            />
            <text
              x={l.x}
              y={l.y}
              textAnchor="middle"
              dominantBaseline="middle"
              className="fill-teal-700"
              style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.5 }}
              paintOrder="stroke"
              stroke="#ffffff"
              strokeWidth={3}
            >
              {l.text}
            </text>
          </g>
        ))}
    </svg>
  );
}
