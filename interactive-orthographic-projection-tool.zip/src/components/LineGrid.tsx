import { useRef, useState } from "react";
import {
  pathSegments,
  segMidpoint,
  type Pt,
  type SegFeedback,
  type SegSet,
} from "../lib/segments";

interface Props {
  title: string;
  subtitle?: string;
  rows: number;
  cols: number;
  cell: number;
  segments: SegSet;
  feedback?: SegFeedback | null;
  tool: "line" | "erase";
  showHelperGrid: boolean;
  accent?: string;
  locked?: boolean;
  onChange: (next: SegSet) => void;
}

const PAD = 14;

export default function LineGrid({
  title,
  subtitle,
  rows,
  cols,
  cell,
  segments,
  feedback,
  tool,
  showHelperGrid,
  accent = "text-slate-700",
  locked = false,
  onChange,
}: Props) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [start, setStart] = useState<Pt | null>(null);
  const [cursor, setCursor] = useState<Pt | null>(null);
  const [hover, setHover] = useState<Pt | null>(null);
  const dragging = useRef(false);

  const W = cols * cell + PAD * 2;
  const H = rows * cell + PAD * 2;

  const X = (c: number) => PAD + c * cell;
  const Y = (r: number) => PAD + r * cell;

  function localPoint(e: React.PointerEvent): { x: number; y: number } | null {
    const el = svgRef.current;
    if (!el) return null;
    const rect = el.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * W,
      y: ((e.clientY - rect.top) / rect.height) * H,
    };
  }

  function snap(e: React.PointerEvent): Pt | null {
    const p = localPoint(e);
    if (!p) return null;
    const c = Math.max(0, Math.min(cols, Math.round((p.x - PAD) / cell)));
    const r = Math.max(0, Math.min(rows, Math.round((p.y - PAD) / cell)));
    return { r, c };
  }

  /** Borra los segmentos cuyo punto medio queda bajo el puntero. */
  function eraseAt(e: React.PointerEvent) {
    const p = localPoint(e);
    if (!p) return;
    const next = new Set(segments);
    let changed = false;
    segments.forEach((k) => {
      const m = segMidpoint(k);
      const dx = X(m.x) - p.x;
      const dy = Y(m.y) - p.y;
      if (Math.hypot(dx, dy) < cell * 0.45) {
        next.delete(k);
        changed = true;
      }
    });
    if (changed) onChange(next);
  }

  function onDown(e: React.PointerEvent) {
    if (locked) return;
    (e.currentTarget as Element).setPointerCapture?.(e.pointerId);
    dragging.current = true;
    if (tool === "erase") {
      eraseAt(e);
      return;
    }
    const p = snap(e);
    if (!p) return;
    setStart(p);
    setCursor(p);
  }

  function onMove(e: React.PointerEvent) {
    if (locked) return;
    const p = snap(e);
    setHover(p);
    if (!dragging.current) return;
    if (tool === "erase") {
      eraseAt(e);
      return;
    }
    if (!start || !p) return;
    // la línea se mantiene horizontal o vertical (como con la escuadra)
    const dr = p.r - start.r;
    const dc = p.c - start.c;
    setCursor(
      Math.abs(dc) >= Math.abs(dr) ? { r: start.r, c: p.c } : { r: p.r, c: start.c },
    );
  }

  function onUp() {
    dragging.current = false;
    if (tool === "line" && start && cursor) {
      const keys = pathSegments(start, cursor);
      if (keys.length) {
        const next = new Set(segments);
        keys.forEach((k) => next.add(k));
        onChange(next);
      }
    }
    setStart(null);
    setCursor(null);
  }

  function renderSeg(k: string, color: string, width: number, dash?: string, key?: string) {
    const [t, rs, cs] = k.split(":");
    const r = Number(rs);
    const c = Number(cs);
    const x1 = X(c);
    const y1 = Y(r);
    const x2 = t === "H" ? X(c + 1) : X(c);
    const y2 = t === "H" ? Y(r) : Y(r + 1);
    return (
      <line
        key={key ?? k}
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        stroke={color}
        strokeWidth={width}
        strokeLinecap="round"
        strokeDasharray={dash}
      />
    );
  }

  const dots: React.ReactNode[] = [];
  for (let r = 0; r <= rows; r++)
    for (let c = 0; c <= cols; c++)
      dots.push(<circle key={`d${r}-${c}`} cx={X(c)} cy={Y(r)} r={1.7} fill="#94a3b8" />);

  const helper: React.ReactNode[] = [];
  if (showHelperGrid) {
    for (let r = 0; r <= rows; r++)
      helper.push(
        <line
          key={`hr${r}`}
          x1={X(0)}
          y1={Y(r)}
          x2={X(cols)}
          y2={Y(r)}
          stroke="#e2e8f0"
          strokeWidth={1}
        />,
      );
    for (let c = 0; c <= cols; c++)
      helper.push(
        <line
          key={`hc${c}`}
          x1={X(c)}
          y1={Y(0)}
          x2={X(c)}
          y2={Y(rows)}
          stroke="#e2e8f0"
          strokeWidth={1}
        />,
      );
  }

  const preview =
    start && cursor && (start.r !== cursor.r || start.c !== cursor.c) ? (
      <line
        x1={X(start.c)}
        y1={Y(start.r)}
        x2={X(cursor.c)}
        y2={Y(cursor.r)}
        stroke="#4f46e5"
        strokeWidth={4}
        strokeLinecap="round"
        strokeDasharray="6 5"
        opacity={0.8}
      />
    ) : null;

  return (
    <div className="flex flex-col items-center gap-1.5">
      <div className="text-center">
        <div className={`text-[13px] font-bold uppercase tracking-wider ${accent}`}>{title}</div>
        {subtitle && <div className="text-[10px] text-slate-400">{subtitle}</div>}
      </div>
      <svg
        ref={svgRef}
        width={W}
        height={H}
        viewBox={`0 0 ${W} ${H}`}
        className={`rounded-lg bg-white ring-1 transition ${
          locked
            ? "cursor-not-allowed ring-slate-300 opacity-95"
            : tool === "erase"
              ? "cursor-cell ring-rose-300"
              : "cursor-crosshair ring-slate-200"
        }`}
        style={{ touchAction: "none" }}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
        onPointerLeave={() => {
          setHover(null);
          if (dragging.current) onUp();
        }}
      >
        {helper}
        {dots}

        {/* líneas que faltan (solo al comprobar) */}
        {feedback &&
          [...feedback.missing].map((k) => renderSeg(k, "#f43f5e", 3, "7 5", `m${k}`))}

        {/* líneas dibujadas por el alumno */}
        {!feedback && [...segments].map((k) => renderSeg(k, "#1e293b", 4))}
        {feedback && [...feedback.correct].map((k) => renderSeg(k, "#059669", 4.5, undefined, `c${k}`))}
        {feedback && [...feedback.extra].map((k) => renderSeg(k, "#dc2626", 4.5, undefined, `e${k}`))}

        {preview}

        {hover && tool === "line" && !locked && (
          <circle cx={X(hover.c)} cy={Y(hover.r)} r={4} fill="#4f46e5" opacity={0.75} />
        )}
      </svg>
    </div>
  );
}
