import { useEffect } from "react";
import { formatTime, toCSV, type SaveData } from "../lib/storage";

interface Props {
  data: SaveData;
  onClose: () => void;
}

export default function Report({ data, onClose }: Props) {
  // marca el <body> para que al imprimir solo se vea la hoja del informe
  useEffect(() => {
    document.body.classList.add("report-open");
    return () => document.body.classList.remove("report-open");
  }, []);

  const rows = Object.values(data.results).sort((a, b) => a.date.localeCompare(b.date));
  const n = rows.length;
  const perfect = rows.filter((r) => r.errors === 0).length;
  const avg = n ? Math.round(rows.reduce((s, r) => s + r.score, 0) / n) : 0;
  const totalTime = rows.reduce((s, r) => s + r.time, 0);
  const totalErrors = rows.reduce((s, r) => s + r.errors, 0);
  const byView = {
    alzado: rows.reduce((s, r) => s + r.detail.alzado, 0),
    perfil: rows.reduce((s, r) => s + r.detail.perfil, 0),
    planta: rows.reduce((s, r) => s + r.detail.planta, 0),
  };
  const worst =
    byView.alzado >= byView.perfil && byView.alzado >= byView.planta
      ? "el alzado"
      : byView.perfil >= byView.planta
        ? "el perfil"
        : "la planta";

  function downloadCSV() {
    const blob = new Blob(["\uFEFF" + toCSV(data)], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `vistas_${(data.student || "alumno").replace(/\s+/g, "_")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="fixed inset-0 z-50 overflow-auto bg-slate-900/60 p-4 print:static print:bg-white print:p-0">
      <div className="report-sheet mx-auto w-full max-w-3xl rounded-2xl bg-white p-6 shadow-2xl print:max-w-none print:rounded-none print:shadow-none">
        {/* Barra de acciones (no se imprime) */}
        <div className="mb-5 flex flex-wrap items-center gap-2 print:hidden">
          <h2 className="mr-auto text-lg font-black text-slate-900">Informe de la actividad</h2>
          <button
            onClick={() => window.print()}
            className="rounded-lg bg-indigo-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-indigo-500"
          >
            🖨️ Imprimir / Guardar PDF
          </button>
          <button
            onClick={downloadCSV}
            className="rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50"
          >
            ⬇️ Descargar CSV
          </button>
          <button
            onClick={onClose}
            className="rounded-lg bg-slate-800 px-3.5 py-2 text-sm font-semibold text-white hover:bg-slate-700"
          >
            Cerrar
          </button>
        </div>

        {/* Cabecera del informe */}
        <div className="border-b-2 border-slate-800 pb-3">
          <h1 className="text-xl font-black tracking-tight text-slate-900">
            Vistas diédricas · alzado, planta y perfil
          </h1>
          <p className="text-sm text-slate-500">
            Informe de resultados · Dibujo Técnico · {new Date().toLocaleDateString("es-ES")}
          </p>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
          <div>
            <span className="text-slate-500">Alumno/a: </span>
            <b className="text-slate-900">{data.student || "________________________"}</b>
          </div>
          <div>
            <span className="text-slate-500">Grupo: </span>
            <b className="text-slate-900">{data.group || "____________"}</b>
          </div>
        </div>

        {/* Resumen */}
        <div className="mt-5 grid grid-cols-4 gap-3 text-center">
          {[
            { k: "Ejercicios", v: String(n) },
            { k: "Perfectos", v: `${perfect}/${n || 0}` },
            { k: "Media", v: `${avg}%` },
            { k: "Tiempo total", v: formatTime(totalTime) },
          ].map((c) => (
            <div key={c.k} className="rounded-xl border border-slate-300 p-3">
              <div className="text-xl font-black text-slate-900">{c.v}</div>
              <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                {c.k}
              </div>
            </div>
          ))}
        </div>

        {/* Tabla */}
        {n === 0 ? (
          <p className="mt-6 rounded-xl bg-slate-50 p-4 text-sm text-slate-500">
            Todavía no has corregido ningún ejercicio.
          </p>
        ) : (
          <table className="mt-5 w-full border-collapse text-sm">
            <thead>
              <tr className="border-b-2 border-slate-300 text-left text-[11px] uppercase tracking-wide text-slate-500">
                <th className="py-2">#</th>
                <th className="py-2">Pieza</th>
                <th className="py-2 text-center">Nivel</th>
                <th className="py-2 text-center">Alz.</th>
                <th className="py-2 text-center">Perf.</th>
                <th className="py-2 text-center">Plan.</th>
                <th className="py-2 text-center">Errores</th>
                <th className="py-2 text-center">Acierto</th>
                <th className="py-2 text-center">Tiempo</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.pieceId} className="border-b border-slate-200">
                  <td className="py-1.5 text-slate-400">{i + 1}</td>
                  <td className="py-1.5 font-semibold text-slate-800">
                    {r.pieceName}
                    {r.random && <span className="text-slate-400"> (aleatoria)</span>}
                  </td>
                  <td className="py-1.5 text-center text-slate-500">{r.level}</td>
                  <td className="py-1.5 text-center">{r.detail.alzado || "·"}</td>
                  <td className="py-1.5 text-center">{r.detail.perfil || "·"}</td>
                  <td className="py-1.5 text-center">{r.detail.planta || "·"}</td>
                  <td className="py-1.5 text-center font-semibold">{r.errors}</td>
                  <td
                    className={`py-1.5 text-center font-black ${
                      r.score === 100
                        ? "text-emerald-600"
                        : r.score >= 70
                          ? "text-amber-600"
                          : "text-rose-600"
                    }`}
                  >
                    {r.score}%
                  </td>
                  <td className="py-1.5 text-center text-slate-500">{formatTime(r.time)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {n > 0 && (
          <div className="mt-4 rounded-xl bg-slate-50 p-3 text-xs text-slate-600">
            <b>Observaciones automáticas:</b> {totalErrors === 0 ? (
              <>sin errores en ninguna vista. Excelente dominio del sistema diédrico.</>
            ) : (
              <>
                {totalErrors} líneas erróneas en total. La vista con más fallos ha sido{" "}
                <b>{worst}</b> (alzado {byView.alzado} · perfil {byView.perfil} · planta{" "}
                {byView.planta}). Conviene repasar las aristas interiores de los escalones.
              </>
            )}
          </div>
        )}

        <div className="mt-8 flex justify-between text-xs text-slate-400">
          <span>Firma del alumno/a: ________________________</span>
          <span>Visto bueno del profesor/a: ________________________</span>
        </div>
      </div>
    </div>
  );
}
