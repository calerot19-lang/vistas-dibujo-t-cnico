// Modelo de piezas formadas por cubos y cálculo de sus vistas diédricas
// Sistema europeo (1er diedro):
//   Alzado  -> arriba izquierda   (se mira desde el frente,  dirección +Y)
//   Perfil  -> arriba derecha     (vista lateral izquierda, se mira desde la izquierda, dirección +X)
//   Planta  -> abajo izquierda    (se mira desde arriba, dirección -Z)
//
// Ejes:  x = anchura (derecha), y = profundidad (hacia atrás), z = altura (arriba)

export type Grid = boolean[][];

export interface Piece {
  id: string;
  name: string;
  level: 1 | 2 | 3;
  W: number; // nº de cubos en x
  D: number; // nº de cubos en y
  H: number; // nº de cubos en z
  cells: boolean[][][]; // cells[z][y][x]
}

/**
 * Crea una pieza a partir de "capas" de texto.
 * layers[0] = capa inferior (z = 0). En cada capa la primera fila es la de
 * ATRÁS (y = D-1) y la última la de DELANTE (y = 0), como en una planta.
 * '#' o 'X' = hay cubo, cualquier otro carácter = vacío.
 */
export function makePiece(
  id: string,
  name: string,
  level: 1 | 2 | 3,
  layers: string[][],
): Piece {
  const H = layers.length;
  const D = layers[0].length;
  const W = layers[0][0].length;
  const cells: boolean[][][] = [];
  for (let z = 0; z < H; z++) {
    const layer: boolean[][] = [];
    for (let y = 0; y < D; y++) {
      const row = layers[z][D - 1 - y] ?? "";
      const arr: boolean[] = [];
      for (let x = 0; x < W; x++) {
        const ch = row[x] ?? ".";
        arr.push(ch === "#" || ch === "X" || ch === "x");
      }
      layer.push(arr);
    }
    cells.push(layer);
  }
  return { id, name, level, W, D, H, cells };
}

export function solid(p: Piece, x: number, y: number, z: number): boolean {
  if (x < 0 || y < 0 || z < 0 || x >= p.W || y >= p.D || z >= p.H) return false;
  return p.cells[z][y][x];
}

export function countCubes(p: Piece): number {
  let n = 0;
  for (let z = 0; z < p.H; z++)
    for (let y = 0; y < p.D; y++) for (let x = 0; x < p.W; x++) if (p.cells[z][y][x]) n++;
  return n;
}

export function emptyGrid(rows: number, cols: number): Grid {
  return Array.from({ length: rows }, () => Array.from({ length: cols }, () => false));
}

export interface Views {
  alzado: Grid; // filas = H (arriba = z máx), columnas = W (izq = x 0)
  perfil: Grid; // filas = H, columnas = D (izq = y máx -> fondo)
  planta: Grid; // filas = D (arriba = y máx -> fondo), columnas = W
}

export function computeViews(p: Piece): Views {
  const alzado = emptyGrid(p.H, p.W);
  const perfil = emptyGrid(p.H, p.D);
  const planta = emptyGrid(p.D, p.W);

  for (let z = 0; z < p.H; z++) {
    for (let y = 0; y < p.D; y++) {
      for (let x = 0; x < p.W; x++) {
        if (!p.cells[z][y][x]) continue;
        alzado[p.H - 1 - z][x] = true;
        perfil[p.H - 1 - z][p.D - 1 - y] = true;
        planta[p.D - 1 - y][x] = true;
      }
    }
  }
  return { alzado, perfil, planta };
}

export function gridsEqual(a: Grid, b: Grid): boolean {
  for (let r = 0; r < a.length; r++)
    for (let c = 0; c < a[r].length; c++) if (a[r][c] !== b[r][c]) return false;
  return true;
}

export function countDiff(a: Grid, b: Grid): number {
  let n = 0;
  for (let r = 0; r < a.length; r++)
    for (let c = 0; c < a[r].length; c++) if (a[r][c] !== b[r][c]) n++;
  return n;
}

/* ------------------------------------------------------------------ */
/*  Colección de piezas                                                */
/* ------------------------------------------------------------------ */

const L1: Piece[] = [
  makePiece("a1", "Escalón", 1, [
    ["##", "##"],
    ["##", ".."],
  ]),
  makePiece("a2", "Muro lateral", 1, [
    ["##", "##"],
    ["#.", "#."],
  ]),
  makePiece("a3", "Cubito en la esquina", 1, [
    ["##", "##"],
    ["#.", ".."],
  ]),
  makePiece("a4", "Rincón", 1, [
    ["##", "#."],
    ["#.", ".."],
  ]),
  makePiece("a5", "Diagonal", 1, [
    ["##", "##"],
    [".#", "#."],
  ]),
  makePiece("a6", "Sillón", 1, [
    ["##", "##"],
    ["##", "#."],
  ]),
  makePiece("a7", "Torre trasera", 1, [
    ["##", ".#"],
    [".#", ".#"],
  ]),
  makePiece("a8", "Banco", 1, [
    ["#.", "##"],
    ["#.", "#."],
  ]),
];

const L2: Piece[] = [
  makePiece("b1", "Escalera", 2, [
    ["###", "###", "###"],
    ["###", "###", "..."],
    ["###", "...", "..."],
  ]),
  makePiece("b2", "Pieza en L", 2, [
    ["###", "#..", "#.."],
    ["###", "#..", "#.."],
    ["###", "#..", "#.."],
  ]),
  makePiece("b3", "Rampa de esquina", 2, [
    ["###", "###", "###"],
    ["##.", "##.", "..."],
    ["#..", "...", "..."],
  ]),
  makePiece("b4", "Pieza en T", 2, [
    ["###", ".#.", ".#."],
    ["###", ".#.", "..."],
    ["###", "...", "..."],
  ]),
  makePiece("b5", "Torre lateral", 2, [
    ["###", "###", "###"],
    ["..#", "..#", "..#"],
    ["..#", "...", "..."],
  ]),
  makePiece("b6", "Puente", 2, [
    ["###", "#.#", "###"],
    ["###", "...", "###"],
    ["###", "...", "..."],
  ]),
  makePiece("b7", "Peldaños", 2, [
    ["###", "###", "###"],
    [".##", ".##", "..."],
    [".#.", "...", "..."],
  ]),
  makePiece("b8", "Rincón alto", 2, [
    ["###", "###", "###"],
    ["###", "..#", "..#"],
    ["###", "...", "..."],
  ]),
  makePiece("b9", "Zigzag", 2, [
    ["##.", ".##", "..#"],
    ["#..", ".#.", "..#"],
    ["#..", "...", "..#"],
  ]),
];

const L3: Piece[] = [
  makePiece("c1", "Bloque escalonado", 3, [
    ["####", "####", "####"],
    ["####", "##..", "##.."],
    ["##..", "#...", "...."],
  ]),
  makePiece("c2", "Mueble", 3, [
    ["####", "#..#", "#..#"],
    ["####", "#..#", "...."],
    ["##.#", "....", "...."],
  ]),
  makePiece("c3", "Pieza compleja", 3, [
    ["###.", "####", ".###"],
    ["#...", "#..#", ".##."],
    ["#...", "#...", "...."],
  ]),
  makePiece("c4", "Doble escalera", 3, [
    ["####", "####", "####"],
    ["#..#", "#..#", "#..#"],
    ["#..#", "....", "#..#"],
    ["#..#", "....", "...."],
  ]),
  makePiece("c5", "Soporte en U", 3, [
    ["###", "#.#", "#.#", "###"],
    ["#.#", "...", "...", "###"],
    ["#.#", "...", "...", "###"],
  ]),
];

export const PIECES: Piece[] = [...L1, ...L2, ...L3];

export const LEVELS: { level: 1 | 2 | 3; label: string; desc: string }[] = [
  { level: 1, label: "Nivel 1 · 2×2×2", desc: "Iniciación: 8 cubos como máximo" },
  { level: 2, label: "Nivel 2 · 3×3×3", desc: "Intermedio: piezas de 27 cubos" },
  { level: 3, label: "Nivel 3 · Libre", desc: "Avanzado: piezas mayores" },
];

export function piecesOfLevel(level: 1 | 2 | 3): Piece[] {
  return PIECES.filter((p) => p.level === level);
}

/* ------------------------------------------------------------------ */
/*  Generador de piezas aleatorias                                      */
/* ------------------------------------------------------------------ */

function randomHeights(W: number, D: number, H: number): number[][] {
  const hs: number[][] = [];
  for (let y = 0; y < D; y++) {
    const row: number[] = [];
    for (let x = 0; x < W; x++) row.push(Math.floor(Math.random() * (H + 1)));
    hs.push(row);
  }
  return hs;
}

function connectedBase(hs: number[][]): boolean {
  const D = hs.length;
  const W = hs[0].length;
  let start: [number, number] | null = null;
  let total = 0;
  for (let y = 0; y < D; y++)
    for (let x = 0; x < W; x++)
      if (hs[y][x] > 0) {
        total++;
        if (!start) start = [x, y];
      }
  if (!start) return false;
  const seen = new Set<string>();
  const stack = [start];
  while (stack.length) {
    const [x, y] = stack.pop()!;
    const k = `${x},${y}`;
    if (seen.has(k)) continue;
    if (x < 0 || y < 0 || x >= W || y >= D || hs[y][x] === 0) continue;
    seen.add(k);
    stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
  }
  return seen.size === total;
}

export function randomPiece(level: 1 | 2 | 3): Piece {
  const dims =
    level === 1 ? { W: 2, D: 2, H: 2 } : level === 2 ? { W: 3, D: 3, H: 3 } : { W: 4, D: 3, H: 3 };
  const { W, D, H } = dims;

  for (let attempt = 0; attempt < 500; attempt++) {
    const hs = randomHeights(W, D, H);
    let cubes = 0;
    let maxH = 0;
    let cols = 0;
    for (let y = 0; y < D; y++)
      for (let x = 0; x < W; x++) {
        cubes += hs[y][x];
        maxH = Math.max(maxH, hs[y][x]);
        if (hs[y][x] > 0) cols++;
      }
    if (maxH !== H) continue; // debe alcanzar la altura máxima
    if (cubes < Math.max(3, Math.round(W * D * H * 0.3))) continue;
    if (cubes >= W * D * H) continue; // que no sea un prisma macizo
    if (cols < Math.ceil((W * D) / 2)) continue;
    if (!connectedBase(hs)) continue;

    // comprobar que usa todo el ancho y el fondo
    let usesX = new Set<number>();
    let usesY = new Set<number>();
    for (let y = 0; y < D; y++)
      for (let x = 0; x < W; x++)
        if (hs[y][x] > 0) {
          usesX.add(x);
          usesY.add(y);
        }
    if (usesX.size !== W || usesY.size !== D) continue;

    const layers: string[][] = [];
    for (let z = 0; z < H; z++) {
      const rows: string[] = [];
      for (let r = 0; r < D; r++) {
        const y = D - 1 - r;
        let s = "";
        for (let x = 0; x < W; x++) s += hs[y][x] > z ? "#" : ".";
        rows.push(s);
      }
      layers.push(rows);
    }
    return makePiece(`rnd-${Date.now()}-${attempt}`, "Pieza aleatoria", level, layers);
  }
  return piecesOfLevel(level)[0];
}
