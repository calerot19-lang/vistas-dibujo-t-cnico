import type { Piece } from "./pieces";

/**
 * Segmentos unitarios de una cuadrícula de rows x cells.
 * "H:r:c"  -> segmento horizontal sobre la línea r (0..rows), de la columna c a c+1
 * "V:r:c"  -> segmento vertical sobre la línea c (0..cols), de la fila r a r+1
 */
export type SegSet = Set<string>;

export const hKey = (r: number, c: number) => `H:${r}:${c}`;
export const vKey = (r: number, c: number) => `V:${r}:${c}`;

export interface Pt {
  r: number;
  c: number;
}

/** Segmentos unitarios entre dos puntos alineados de la retícula. */
export function pathSegments(a: Pt, b: Pt): string[] {
  const out: string[] = [];
  if (a.r === b.r) {
    const [c0, c1] = a.c < b.c ? [a.c, b.c] : [b.c, a.c];
    for (let c = c0; c < c1; c++) out.push(hKey(a.r, c));
  } else if (a.c === b.c) {
    const [r0, r1] = a.r < b.r ? [a.r, b.r] : [b.r, a.r];
    for (let r = r0; r < r1; r++) out.push(vKey(r, a.c));
  }
  return out;
}

/** Punto medio de un segmento, en coordenadas de retícula. */
export function segMidpoint(key: string): { x: number; y: number } {
  const [t, rs, cs] = key.split(":");
  const r = Number(rs);
  const c = Number(cs);
  return t === "H" ? { x: c + 0.5, y: r } : { x: c, y: r + 0.5 };
}

/* ------------------------------------------------------------------ */
/*  Mapas de profundidad de cada vista                                  */
/* ------------------------------------------------------------------ */

export type DepthGrid = (number | null)[][]; // null = sin material

export interface ViewDepths {
  alzado: DepthGrid;
  perfil: DepthGrid;
  planta: DepthGrid;
}

/**
 * Para cada casilla de cada vista guarda la distancia al observador de la
 * cara más cercana (null si no hay material). Sirve para saber dónde hay
 * aristas visibles por un cambio de profundidad (escalones).
 */
export function computeDepths(p: Piece): ViewDepths {
  const alzado: DepthGrid = Array.from({ length: p.H }, () =>
    Array.from({ length: p.W }, () => null as number | null),
  );
  const perfil: DepthGrid = Array.from({ length: p.H }, () =>
    Array.from({ length: p.D }, () => null as number | null),
  );
  const planta: DepthGrid = Array.from({ length: p.D }, () =>
    Array.from({ length: p.W }, () => null as number | null),
  );

  for (let z = 0; z < p.H; z++) {
    for (let y = 0; y < p.D; y++) {
      for (let x = 0; x < p.W; x++) {
        if (!p.cells[z][y][x]) continue;
        // Alzado: observador delante (y decreciente). Más cerca = y menor.
        const ar = p.H - 1 - z;
        const av = alzado[ar][x];
        alzado[ar][x] = av === null ? y : Math.min(av, y);
        // Perfil izquierdo: observador a la izquierda. Más cerca = x menor.
        const pr = p.H - 1 - z;
        const pc = p.D - 1 - y;
        const pv = perfil[pr][pc];
        perfil[pr][pc] = pv === null ? x : Math.min(pv, x);
        // Planta: observador arriba. Más cerca = z mayor.
        const qr = p.D - 1 - y;
        const d = p.H - 1 - z;
        const qv = planta[qr][x];
        planta[qr][x] = qv === null ? d : Math.min(qv, d);
      }
    }
  }
  return { alzado, perfil, planta };
}

/**
 * Aristas visibles de una vista: contorno (material / vacío) y aristas
 * interiores donde cambia la profundidad de la superficie vista (escalones).
 */
export function solutionSegments(depth: DepthGrid): SegSet {
  const rows = depth.length;
  const cols = depth[0].length;
  const at = (r: number, c: number): number | null | undefined =>
    r < 0 || c < 0 || r >= rows || c >= cols ? undefined : depth[r][c];
  const need = (a: number | null | undefined, b: number | null | undefined) => {
    const fa = a !== undefined && a !== null;
    const fb = b !== undefined && b !== null;
    if (fa !== fb) return true;
    if (fa && fb && a !== b) return true;
    return false;
  };

  const set: SegSet = new Set();
  for (let r = 0; r <= rows; r++)
    for (let c = 0; c < cols; c++) if (need(at(r - 1, c), at(r, c))) set.add(hKey(r, c));
  for (let r = 0; r < rows; r++)
    for (let c = 0; c <= cols; c++) if (need(at(r, c - 1), at(r, c))) set.add(vKey(r, c));
  return set;
}

export interface SegFeedback {
  correct: SegSet;
  extra: SegSet;
  missing: SegSet;
}

export function compareSegments(drawn: SegSet, sol: SegSet): SegFeedback {
  const correct: SegSet = new Set();
  const extra: SegSet = new Set();
  const missing: SegSet = new Set();
  drawn.forEach((k) => (sol.has(k) ? correct.add(k) : extra.add(k)));
  sol.forEach((k) => {
    if (!drawn.has(k)) missing.add(k);
  });
  return { correct, extra, missing };
}
