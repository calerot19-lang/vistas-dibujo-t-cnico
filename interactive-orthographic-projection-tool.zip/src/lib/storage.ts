/**
 * Guardado automático en el navegador (localStorage).
 * Los Set<string> se serializan como arrays.
 */

export interface StoredResult {
  pieceId: string;
  pieceName: string;
  level: 1 | 2 | 3;
  random: boolean;
  errors: number;
  score: number;
  time: number;
  date: string; // ISO
  detail: { alzado: number; perfil: number; planta: number }; // errores por vista
  segs: { alzado: string[]; perfil: string[]; planta: string[] };
  feedback: {
    alzado: { correct: string[]; extra: string[]; missing: string[] };
    perfil: { correct: string[]; extra: string[]; missing: string[] };
    planta: { correct: string[]; extra: string[]; missing: string[] };
  };
}

export interface SaveData {
  student: string;
  group: string;
  results: Record<string, StoredResult>;
}

const KEY = "vistas-diedricas-v1";

export const emptySave = (): SaveData => ({ student: "", group: "", results: {} });

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return emptySave();
    const data = JSON.parse(raw) as SaveData;
    return {
      student: data.student ?? "",
      group: data.group ?? "",
      results: data.results ?? {},
    };
  } catch {
    return emptySave();
  }
}

export function persist(data: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* almacenamiento no disponible (modo privado): se sigue sin guardar */
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignorar */
  }
}

export function storageAvailable(): boolean {
  try {
    const k = "__test__";
    localStorage.setItem(k, "1");
    localStorage.removeItem(k);
    return true;
  } catch {
    return false;
  }
}

export function formatTime(s: number): string {
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}

/** Exporta los resultados a CSV (para que el profesor los recoja fácilmente). */
export function toCSV(data: SaveData): string {
  const head = [
    "Alumno",
    "Grupo",
    "Pieza",
    "Nivel",
    "Aciertos (%)",
    "Errores",
    "Err. alzado",
    "Err. perfil",
    "Err. planta",
    "Tiempo",
    "Fecha",
  ].join(";");
  const rows = Object.values(data.results)
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((r) =>
      [
        data.student || "(sin nombre)",
        data.group || "",
        r.pieceName + (r.random ? " (aleatoria)" : ""),
        r.level,
        r.score,
        r.errors,
        r.detail.alzado,
        r.detail.perfil,
        r.detail.planta,
        formatTime(r.time),
        new Date(r.date).toLocaleString("es-ES"),
      ].join(";"),
    );
  return [head, ...rows].join("\n");
}
